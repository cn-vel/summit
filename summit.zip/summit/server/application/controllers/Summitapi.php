<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class SummitApi extends MY_Controller {

	public function index()
	{
		
	}
}
